# from odoo import models, fields, api
import sys
# import os
sys.path.append('/home/admin1/Documents/projects17')
# import tempfile
# import base64
# from resume_ai.predict import predict_resume_score

# class HrApplicant(models.Model):
#     _inherit = 'hr.applicant'

#     resume_atteched = fields.Binary(string="Resume Upload")
#     resume_atteched_filename = fields.Char(string="Attached Filename")
#     resume_score = fields.Float("Resume Score (%)", store=True)
    
#     @api.model
#     def write(self, vals):
#         res = super(HrApplicant, self).write(vals)
#         for record in self:
#             if vals.get('stage_id'):
#                 stage_name = self.env['hr.recruitment.stage'].browse(vals['stage_id']).name.lower()
#                 if stage_name == 'initial qualification' and record.resume_atteched:
#                     pdf_data = base64.b64decode(record.resume_atteched)
#                     with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp:
#                         temp.write(pdf_data)
#                         temp_path = temp.name
#                     score = predict_resume_score(temp_path)
#                     record.resume_score = score
#                     os.unlink(temp_path)
#         return res

from odoo import models, fields, api
import os, base64, tempfile
from resume_ai.predict import predict_resume_score
from resume_ai.resume_parser import extract_text_from_pdf


class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    resume_atteched = fields.Binary(string="Resume Upload")
    resume_atteched_filename = fields.Char(string="Attached Filename")
    resume_score = fields.Float("Resume Score (%)")
    # must_have_matched_skills_ids = fields.Many2many('hr.skill', string="Matched Must-Have Skills")
    must_have_matched_skills_ids = fields.Many2many(
        'hr.skill',
        'applicant_must_have_skill_rel',  # unique table name
        'applicant_id', 'skill_id',
        string="Matched Must-Have Skills"
    )

    good_to_have_matched_skills_ids = fields.Many2many(
        'hr.skill',
        'applicant_good_to_have_skill_rel',  # another unique table name
        'applicant_id', 'skill_id',
        string="Matched Good-to-Have Skills"
    )

    avg_skill_progress = fields.Integer(string="Avg Must-Have Skill Match (%)")

    @api.model
    def write(self, vals):
        res = super().write(vals)
        for record in self:
            if vals.get('stage_id'):
                stage_name = self.env['hr.recruitment.stage'].browse(vals['stage_id']).name.lower()
                if stage_name == 'initial qualification' and record.resume_atteched:
                    # Decode and save resume
                    pdf_data = base64.b64decode(record.resume_atteched)
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp:
                        temp.write(pdf_data)
                        temp_path = temp.name
                    
                    # Score prediction
                    record.resume_score = predict_resume_score(temp_path)

                    # Extract text
                    resume_text = extract_text_from_pdf(temp_path).lower()

                    # Clean up file
                    os.unlink(temp_path)

                    # Skill matching
                    matched_skills = []
                    match_percents = []

                    for rel in record.job_id.must_have_skill_rel_ids:
                        skill_name = rel.skill_id.name.lower()
                        if skill_name in resume_text:
                            matched_skills.append(rel.skill_id.id)
                            match_percents.append(rel.match_percent)

                    # Update fields
                    record.must_have_matched_skills_ids = [(6, 0, matched_skills)]
                    record.avg_skill_progress = round(
                        sum(match_percents) / len(match_percents), 2
                    ) if match_percents else 0.0

        return res
